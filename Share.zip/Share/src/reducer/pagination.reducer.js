const inailValue = {
    value:1
}

const paginationReducer = (state=inailValue,action) =>{
    console.log("=============",action)
    if(action.type==="INC"){
        state = {
            value:state.value + 1
        }
        return state;
    }else if(action.type==="DEC"){
        state = {
            value:state.value - 1
        }
        return state;
    }
    return state;
}


export default paginationReducer;