import { combineReducers } from "redux";
import paginationReducer from './pagination.reducer'

export default combineReducers({
    pageNumber:paginationReducer
})