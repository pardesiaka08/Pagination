const actionType= (type)=>dispatch=>{
    return dispatch({
        type: type,
        payload: ""
      });
}

export default actionType