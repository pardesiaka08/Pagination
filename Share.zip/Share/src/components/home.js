import {Component} from "react";
import './home.css';
import {connect} from "react-redux";

class Home extends Component {
    constructor(){
        super()
        this.state={
            
        }
    }

    
   display = () =>{
      
        return(
                  <table className="display-table" id="customers">
                      <tbody>
                      <tr>
                        <th>Name</th>
                        <th>Type</th>
                        <th>Company</th>
                      </tr>
                      {this.props.rawData.map((item,key)=>{
                          return <tr key={key}>
                         <td>{item.name}</td>
                         <td>{item.type}</td>
                         <td>{item.company}</td>
                       </tr>
                      }
                      )}
                    </tbody>
                  </table>
            )
   }

 render(){
    console.log(this.props,"props");
     return(
            <div className="home-page-wrapper">
                 {this.display()}
            </div>
     )
 }
}

const mapStateToProps = (state)=>{
  return {
      currentPage:state.pageNumber.value
  }
}
export default connect(mapStateToProps,{})(Home);