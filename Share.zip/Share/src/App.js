import { Component } from 'react';
import './App.css';
import Home from "./components/home";
import data from "./data.json";


class App extends Component {
  constructor(props) {
    super(props)
    this.state = {
      displayData: data.length>9 ? data.slice(0,10): data.slice(0,data.length),
      maxValue: Math.ceil(data.length / 10),
      currentPageNumber: 1,
      searchInput:"",
      startPagination:1,
      endPagination:3
    }
  }

  handlePagination = (pageNumber) => {
    let initialIndex = (pageNumber-1) * 10;
    let finalIndex = (pageNumber * 10);
    this.setState({
      endPagination:pageNumber+3,
      currentPageNumber:pageNumber,
      displayData:data.length>finalIndex ? data.slice(initialIndex,finalIndex): data.slice(initialIndex,data.length),
    })
  }

  handleSearch = () =>{
    let searchText = this.state.searchInput.toLowerCase();
    this.setState({
      displayData:data.filter((item) =>  item.company.toLowerCase().indexOf(searchText) !== -1 ||  item.name.toLowerCase().indexOf(searchText) !== -1),
      searchInput:""
    })

  }

  render() {
    let pageNumber = 1;
    return (
      <div className="app-wrapper">
        <div className="search-box">
          <input type="text"
           className="input-box"
           placeholder="Search Company Name"
           value={this.state.searchInput}
           onChange={(event)=>{this.setState({
            searchInput:event.target.value
          })}}/>
          <button className="search-button" onClick={this.handleSearch}>Search</button>
        </div>
        <Home rawData={this.state.displayData} />
        <div className="center">
          <div className="pagination">
{       this.state.currentPageNumber>1 &&      <span className="span-btn" onClick={()=>this.handlePagination(this.state.currentPageNumber-1)} >&laquo;</span>
}            {[...Array(this.state.maxValue)].map((page, key) => {
              let activeClass = this.state.currentPageNumber === key+1 ? "active span-btn" : "span-btn"
              return (
                <span >
                     {this.state.currentPageNumber<=key+1 && this.state.endPagination>=key && <span className={activeClass} onClick={()=>this.handlePagination(key+1)}>{key+1}</span>}
                     {/* {this.state.currentPageNumber + 3< this.state.maxValue && key+1 == this.state.maxValue && <span className={activeClass} onClick={()=>this.handlePagination(key+1)}>{pageNumber++}</span>} */}
                 </span>
              )
            })}
{         this.state.currentPageNumber<this.state.maxValue &&  <span className="span-btn" onClick={()=>this.handlePagination(this.state.currentPageNumber+1)}>&raquo;</span>
}          </div>
        </div>
      </div>
    )
  }
}

export default App;
